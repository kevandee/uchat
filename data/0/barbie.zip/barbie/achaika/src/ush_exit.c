#include "../inc/ush.h"

void ush_exit(t_ush *ush) {
    if (ush -> count_bg) {
        mx_printerr("ush: you have suspended jobs.\n");
        return;
    }
    int code = 0;
    if (ush -> argv) {
            mx_disable_canon();
            code = mx_atoi(ush -> argv -> data);
            free_sh (&ush);
            //remove(".redir");
            exit(code);
    }
    mx_disable_canon();
    code = ush->err;
    free_sh (&ush);
    //remove(".redir");
    exit(code);
}
