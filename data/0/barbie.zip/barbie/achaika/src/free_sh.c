#include "../inc/ush.h"

void free_sh(t_ush **ush) {
    if (malloc_size((*ush) -> pwd) != 0)
        mx_strdel(&((*ush)->pwd));
    if (malloc_size((*ush) -> prev_pwd) != 0)
        mx_strdel(&((*ush)->prev_pwd));

    mx_clear_ldata(&(*ush)->argv);
    mx_clear_list(&(*ush)->argv);

    mx_clear_ldata(&(*ush)->cmd_queue);
    mx_clear_list(&(*ush)->cmd_queue);

    mx_del_strarr (&(*ush)->argv_arr);

    mx_strdel(&(*ush)->input);

    free(*ush);
    *ush = NULL;
}
